import React from "react";

function GuestPage() {
  return (
    <div>
      <h1>Welcome, Guest!</h1>
      <p>
        Here are the available flight details. Please log in to book a ticket.
      </p>
    </div>
  );
}

export default GuestPage;
