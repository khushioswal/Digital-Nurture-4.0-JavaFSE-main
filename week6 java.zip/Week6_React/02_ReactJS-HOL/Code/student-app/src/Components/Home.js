import React, {Component} from "react";

class Home extends Component {
    render() {
        return (
            <div>
                <h3>Welcome to Home Page of Student Management System</h3>
            </div>
        );
    }
}

export default Home;