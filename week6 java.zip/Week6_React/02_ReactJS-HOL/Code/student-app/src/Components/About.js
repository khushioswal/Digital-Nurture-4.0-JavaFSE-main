import React, {Component} from "react";

class About extends Component {
    render() {
        return (
            <div>
                <h3>Welcome to About Page of Student Manangement System</h3>
            </div>
        )
    }
}

export default About