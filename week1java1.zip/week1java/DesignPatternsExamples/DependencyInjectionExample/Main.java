public class Main {
    public static void main(String[] args) {
        // Create repository object
        CustomerRepository repository = new CustomerRepositoryImpl();

        // Inject it into the service
        CustomerService service = new CustomerService(repository);

        // Use the service
        service.getCustomerInfo("C101");
    }
}
