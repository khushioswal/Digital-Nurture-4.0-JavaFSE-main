public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public String findCustomerById(String customerId) {
        // Simulate fetching customer from DB
        return "Customer[id=" + customerId + ", name=Ishan Jain]";
    }
}
