public class CustomerService {
    private final CustomerRepository repository;

    // Constructor injection
    public CustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    public void getCustomerInfo(String customerId) {
        String customerData = repository.findCustomerById(customerId);
        System.out.println("Customer Data: " + customerData);
    }
}
