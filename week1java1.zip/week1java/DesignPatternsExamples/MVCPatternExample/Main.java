public class Main {
    public static void main(String[] args) {
        // Create model object
        Student student = new Student("Ishan", "C101", "A");

        // Create view object
        StudentView view = new StudentView();

        // Create controller object
        StudentController controller = new StudentController(student, view);

        // Display initial info
        controller.updateView();

        // Modify student info
        controller.setStudentName("Ishan Jain");
        controller.setStudentGrade("A+");

        // Display updated info
        controller.updateView();
    }
}
