public class Main {
    public static void main(String[] args) {
        // Base notifier
        Notifier notifier = new EmailNotifier();

        // Decorate with SMS
        notifier = new SMSNotifierDecorator(notifier);

        // Decorate with Slack
        notifier = new SlackNotifierDecorator(notifier);

        // Send notification through all channels
        notifier.send("Your order has been shipped!");
    }
}
