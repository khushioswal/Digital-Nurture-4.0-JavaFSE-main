public class Main {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer mobileUser = new MobileApp("Ishan");
        Observer webUser = new WebApp("Ravi");

        stockMarket.registerObserver(mobileUser);
        stockMarket.registerObserver(webUser);

        stockMarket.setStockData("TCS", 3525.50);
        stockMarket.setStockData("INFY", 1448.25);
    }
}
