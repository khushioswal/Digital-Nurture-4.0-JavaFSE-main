public class Main {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("photo1.jpg");
        Image image2 = new ProxyImage("photo2.jpg");

        // Image is not loaded yet
        System.out.println("First time display of photo1:");
        image1.display();  // Will load and display

        System.out.println("\nSecond time display of photo1:");
        image1.display();  // Will only display (not load)

        System.out.println("\nDisplay of photo2:");
        image2.display();  // Will load and display
    }
}
