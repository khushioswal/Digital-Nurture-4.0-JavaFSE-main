public class Main {
    public static void main(String[] args) {
        // Using PayPal through adapter
        PayPalGateway payPalGateway = new PayPalGateway();
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalGateway);
        payPalAdapter.processPayment(1500.00);

        // Using Stripe through adapter
        StripeGateway stripeGateway = new StripeGateway();
        PaymentProcessor stripeAdapter = new StripeAdapter(stripeGateway);
        stripeAdapter.processPayment(2500.00);
    }
}
