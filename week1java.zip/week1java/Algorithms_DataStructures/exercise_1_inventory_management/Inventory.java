import java.util.HashMap;

public class Inventory {
    private HashMap<Integer, Product> products = new HashMap<>();

    public void addProduct(Product p) {
        products.put(p.getProductId(), p);
    }

    public void updateProduct(Product p) {
        products.put(p.getProductId(), p);
    }

    public void deleteProduct(int id) {
        products.remove(id);
    }
}
