public class Forecast {
    public static double futureValue(double current, double rate, int years) {
        if (years == 0) return current;
        return futureValue(current * (1 + rate), rate, years - 1);
    }

    public static double futureValueOptimized(double current, double rate, int years) {
        return current * Math.pow(1 + rate, years);
    }
}
