
// Student.java
class Student {
    private String name;
    private String id;
    public Student(String name, String id) {
        this.name = name;
        this.id = id;
    }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getId() { return id; }
}

// StudentView.java
class StudentView {
    public void displayStudentDetails(String name, String id) {
        System.out.println("Student: " + name + ", ID: " + id);
    }
}

// StudentController.java
class StudentController {
    private Student student;
    private StudentView view;
    public StudentController(Student student, StudentView view) {
        this.student = student;
        this.view = view;
    }
    public void setStudentName(String name) { student.setName(name); }
    public void updateView() {
        view.displayStudentDetails(student.getName(), student.getId());
    }
}

// Main.java
public class Main {
    public static void main(String[] args) {
        Student student = new Student("John", "1234");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(student, view);

        controller.updateView();
        controller.setStudentName("Jane");
        controller.updateView();
    }
}
