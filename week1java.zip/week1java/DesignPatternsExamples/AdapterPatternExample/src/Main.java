
// PaymentProcessor.java
interface PaymentProcessor {
    void processPayment();
}

// PayPalGateway.java (Adaptee)
class PayPalGateway {
    public void makePayment() {
        System.out.println("Payment made using PayPal Gateway.");
    }
}

// PayPalAdapter.java (Adapter)
class PayPalAdapter implements PaymentProcessor {
    private PayPalGateway payPalGateway;

    public PayPalAdapter(PayPalGateway payPalGateway) {
        this.payPalGateway = payPalGateway;
    }

    public void processPayment() {
        payPalGateway.makePayment();
    }
}

// Main.java
public class Main {
    public static void main(String[] args) {
        PayPalGateway gateway = new PayPalGateway();
        PaymentProcessor processor = new PayPalAdapter(gateway);
        processor.processPayment();
    }
}
