
// Document.java
interface Document {
    void open();
}

// WordDocument.java
class WordDocument implements Document {
    public void open() {
        System.out.println("Opening Word document...");
    }
}

// PdfDocument.java
class PdfDocument implements Document {
    public void open() {
        System.out.println("Opening PDF document...");
    }
}

// DocumentFactory.java
abstract class DocumentFactory {
    public abstract Document createDocument();
}

// WordDocumentFactory.java
class WordDocumentFactory extends DocumentFactory {
    public Document createDocument() {
        return new WordDocument();
    }
}

// PdfDocumentFactory.java
class PdfDocumentFactory extends DocumentFactory {
    public Document createDocument() {
        return new PdfDocument();
    }
}

// Main.java
public class Main {
    public static void main(String[] args) {
        DocumentFactory factory = new WordDocumentFactory();
        Document doc = factory.createDocument();
        doc.open();

        factory = new PdfDocumentFactory();
        doc = factory.createDocument();
        doc.open();
    }
}
