
// Observer.java
interface Observer {
    void update(float price);
}

// Stock.java
interface Stock {
    void register(Observer o);
    void deregister(Observer o);
    void notifyObservers();
}

// StockMarket.java
import java.util.ArrayList;
import java.util.List;

class StockMarket implements Stock {
    private List<Observer> observers = new ArrayList<>();
    private float price;

    public void register(Observer o) {
        observers.add(o);
    }
    public void deregister(Observer o) {
        observers.remove(o);
    }
    public void setPrice(float price) {
        this.price = price;
        notifyObservers();
    }
    public void notifyObservers() {
        for (Observer o : observers) {
            o.update(price);
        }
    }
}

// MobileApp.java
class MobileApp implements Observer {
    public void update(float price) {
        System.out.println("MobileApp: Price updated to " + price);
    }
}

// Main.java
public class Main {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();
        Observer mobile = new MobileApp();

        stockMarket.register(mobile);
        stockMarket.setPrice(100);
        stockMarket.setPrice(200);
    }
}
